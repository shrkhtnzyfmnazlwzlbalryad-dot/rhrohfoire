import { createFileRoute, Link } from "@tanstack/react-router";
import {
  Phone,
  MessageCircle,
  Home,
  Snowflake,
  Sofa,
  Zap,
  ShieldCheck,
  Sparkles,
  Droplets,
  CheckCircle,
} from "lucide-react";

import heroImg from "../../public/images/hero-cleaning.jpg";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      {
        title: "الخبراء كلين | خدمات تنظيف المنازل في الرياض",
      },
      {
        name: "description",
        content:
          "الخبراء كلين - خدمات تنظيف شامل في الرياض: تنظيف فلل وشقق، مكيفات، مجالس وسجاد. اتصل الآن 0536871812.",
      },
      {
        property: "og:title",
        content: "الخبراء كلين | خدمات تنظيف المنازل في الرياض",
      },
      {
        property: "og:description",
        content:
          "خدمات تنظيف شامل في الرياض: تنظيف فلل وشقق، مكيفات، مجالس وسجاد. اتصل الآن 0536871812.",
      },
      { property: "og:type", content: "website" },
      { property: "og:image", content: heroImg },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:image", content: heroImg },
    ],
  }),
  component: Index,
});

const PHONE_NUMBER = "0536871812";
const WHATSAPP_LINK = "https://wa.me/966536871812";

function Index() {
  return (
    <div className="relative min-h-screen overflow-hidden bg-gradient-to-br from-[#06202b] via-[#0a3547] to-brand font-body text-white">
      {/* Ambient background glows */}
      <div className="pointer-events-none absolute -top-28 -right-24 size-96 rounded-full bg-brand-accent/25 blur-3xl" />
      <div className="pointer-events-none absolute top-1/3 -left-28 size-[28rem] rounded-full bg-brand/30 blur-3xl" />
      <div className="pointer-events-none absolute bottom-0 right-1/3 size-80 rounded-full bg-brand-cyan/10 blur-3xl" />

      <div className="relative mx-auto max-w-6xl px-6 py-6">
        <Header />

        <main className="mt-14 grid items-center gap-12 lg:mt-20 lg:grid-cols-12">
          <HeroContent />
          <ServicesCard />
        </main>

        <WhyUs />
        <ContactBanner />
        <Footer />
      </div>

      <FloatingActions />
    </div>
  );
}

function Header() {
  return (
    <header className="flex items-center justify-between">
      <Link to="/" className="flex items-center gap-3">
        <div className="grid size-12 place-items-center rounded-2xl bg-white/10 backdrop-blur-md ring-1 ring-white/20">
          <div className="flex items-center gap-1">
            <span className="block size-5 rounded-full bg-gradient-to-br from-brand-accent to-brand" />
            <span className="block size-3 rounded-full bg-white/60" />
          </div>
        </div>
        <div className="leading-tight">
          <p className="font-display text-xl font-extrabold">الخبراء كلين</p>
          <p className="text-xs text-brand-cyan/70">تنظيف شامل متكامل</p>
        </div>
      </Link>

      <nav className="hidden items-center gap-6 text-sm font-medium text-cyan-50/85 md:flex">
        <a href="#services" className="transition hover:text-white">
          خدماتنا
        </a>
        <a href="#why" className="transition hover:text-white">
          لماذا نحن
        </a>
        <a href="#contact" className="transition hover:text-white">
          تواصل
        </a>
        <a
          href={`tel:${PHONE_NUMBER}`}
          className="rounded-full bg-white/10 px-5 py-2.5 backdrop-blur-md ring-1 ring-white/20 transition hover:bg-white/20"
        >
          اتصل الآن
        </a>
      </nav>
    </header>
  );
}

function HeroContent() {
  return (
    <div className="lg:col-span-7">
      <span className="inline-flex items-center gap-2 rounded-full bg-white/10 px-4 py-1.5 text-sm font-medium backdrop-blur-md ring-1 ring-white/20">
        <span className="size-1.5 rounded-full bg-brand-accent" />
        خدمة تنظيف احترافية ٢٤/٧
      </span>

      <h1 className="mt-6 font-display text-4xl font-extrabold leading-[1.15] sm:text-5xl lg:text-6xl">
        نظافة تليق ببيتك،
        <br />
        <span className="bg-gradient-to-l from-brand-accent to-white bg-clip-text text-transparent">
          بلمسة الخبير
        </span>
      </h1>

      <p className="mt-6 max-w-xl text-lg leading-relaxed text-cyan-50/80">
        ننظف فلل وشقق، مكيفات، مجالس وسجاد بمعايير عالمية وفريق مدرّب، ليعود
        المكان منعشاً بأقل وقت وأعلى جودة.
      </p>

      <div className="mt-8 flex flex-wrap items-center gap-4">
        <a
          href={`tel:${PHONE_NUMBER}`}
          className="group inline-flex items-center gap-3 rounded-full bg-gradient-to-l from-brand to-brand-accent px-7 py-4 font-display font-bold shadow-lg shadow-brand/40 transition hover:shadow-brand-accent/50"
        >
          <span className="grid size-9 place-items-center rounded-full bg-white/25 text-lg">
            <Phone className="size-5" />
          </span>
          اتصل الآن
        </a>
        <a
          href={WHATSAPP_LINK}
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center gap-3 rounded-full bg-white/10 px-7 py-4 font-display font-bold backdrop-blur-md ring-1 ring-white/25 transition hover:bg-white/20"
        >
          <span className="grid size-9 place-items-center rounded-full bg-emerald-400/90 text-lg">
            <MessageCircle className="size-5" />
          </span>
          واتساب
        </a>
      </div>

      <div className="mt-10 flex flex-wrap gap-8">
        <div>
          <p className="font-display text-3xl font-extrabold text-brand-accent">
            +٥٠٠
          </p>
          <p className="text-sm text-cyan-100/70">عميل سعيد</p>
        </div>
        <div className="w-px bg-white/15" />
        <div>
          <p className="font-display text-3xl font-extrabold text-brand-accent">
            +١٢٠٠
          </p>
          <p className="text-sm text-cyan-100/70">منزل نظيف</p>
        </div>
        <div className="w-px bg-white/15" />
        <div>
          <p className="font-display text-3xl font-extrabold text-brand-accent">
            ١٠س
          </p>
          <p className="text-sm text-cyan-100/70">خبرة ميدانية</p>
        </div>
      </div>
    </div>
  );
}

function ServicesCard() {
  const services = [
    {
      icon: Home,
      title: "تنظيف فلل وشقق",
      description: "عميق وشامل لكل الزوايا والمساحات",
    },
    {
      icon: Snowflake,
      title: "تنظيف المكيفات",
      description: "سبليت وكاسيت مع التعقيم والتطهير",
    },
    {
      icon: Sofa,
      title: "المجالس والسجاد",
      description: "غسيل بالبخار بدون بقع أو روائح",
    },
    {
      icon: Sparkles,
      title: "تنظيف شامل",
      description: "تغطية كاملة للمنزل من الأعلى للأسفل",
    },
  ];

  return (
    <div id="services" className="lg:col-span-5">
      <div className="rounded-[2rem] bg-white/10 p-6 backdrop-blur-xl ring-1 ring-white/20 shadow-2xl shadow-black/30">
        <p className="font-display text-lg font-bold">خدماتنا الشاملة</p>
        <div className="mt-4 space-y-3">
          {services.map((service) => (
            <div
              key={service.title}
              className="flex items-center gap-4 rounded-2xl bg-white/10 p-4 ring-1 ring-white/10 transition hover:bg-white/15"
            >
              <span className="grid size-12 shrink-0 place-items-center rounded-xl bg-gradient-to-br from-brand/30 to-brand-accent/30 text-2xl">
                <service.icon className="size-6 text-white" />
              </span>
              <div>
                <p className="font-semibold">{service.title}</p>
                <p className="text-sm text-cyan-100/70">{service.description}</p>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-5 overflow-hidden rounded-2xl ring-1 ring-white/10">
          <img
            src={heroImg}
            alt="غرفة معيشة نظيفة ولامعة بعد التنظيف"
            width={1024}
            height={1152}
            className="h-48 w-full object-cover"
          />
        </div>
      </div>
    </div>
  );
}

function WhyUs() {
  const reasons = [
    {
      icon: Zap,
      title: "وصول سريع",
      description: "نصلك في نفس اليوم في أغلب مناطق الرياض.",
    },
    {
      icon: Droplets,
      title: "مواد آمنة",
      description: "منتجات معتمدة آمنة على الأطفال والحيوانات.",
    },
    {
      icon: ShieldCheck,
      title: "ضمان الجودة",
      description: "نعيد العمل مجاناً حتى ترتاح بالنتيجة.",
    },
  ];

  return (
    <div id="why" className="mt-16 grid gap-4 sm:grid-cols-3">
      {reasons.map((reason) => (
        <div
          key={reason.title}
          className="rounded-3xl bg-white/10 p-6 backdrop-blur-md ring-1 ring-white/15"
        >
          <span className="grid size-11 place-items-center rounded-xl bg-brand-accent/20 text-xl">
            <reason.icon className="size-6 text-brand-accent" />
          </span>
          <p className="mt-4 font-display font-bold">{reason.title}</p>
          <p className="mt-1 text-sm text-cyan-100/70">{reason.description}</p>
        </div>
      ))}
    </div>
  );
}

function ContactBanner() {
  return (
    <div
      id="contact"
      className="mt-16 overflow-hidden rounded-[2rem] bg-gradient-to-l from-brand/40 to-brand-accent/20 p-8 text-center backdrop-blur-xl ring-1 ring-white/20 sm:p-12"
    >
      <h2 className="font-display text-3xl font-extrabold sm:text-4xl">
        جاهزون؟ احجز نظافتك اليوم
      </h2>
      <p className="mx-auto mt-3 max-w-xl text-cyan-50/80">
        تواصل معنا الآن وتلقى عرضاً خاصاً على أول خدمة.
      </p>
      <a
        href={`tel:${PHONE_NUMBER}`}
        className="mt-7 inline-flex items-center gap-3 rounded-full bg-white px-8 py-4 font-display text-lg font-extrabold text-brand-deep shadow-xl transition hover:scale-[1.02]"
      >
        <Phone className="size-5" />
        {PHONE_NUMBER}
      </a>

      <div className="mt-6 flex flex-wrap justify-center gap-3 text-sm text-cyan-100/80">
        <span className="inline-flex items-center gap-1.5">
          <CheckCircle className="size-4 text-brand-accent" />
          حجز فوري
        </span>
        <span className="inline-flex items-center gap-1.5">
          <CheckCircle className="size-4 text-brand-accent" />
          أسعار شفافة
        </span>
        <span className="inline-flex items-center gap-1.5">
          <CheckCircle className="size-4 text-brand-accent" />
          فريق موثوق
        </span>
      </div>
    </div>
  );
}

function Footer() {
  return (
    <footer className="mt-14 border-t border-white/10 pt-6 text-center text-sm text-cyan-100/60">
      <p className="font-display font-bold text-white/80">الخبراء كلين</p>
      <p className="mt-1">
        © ٢٠٢٤ جميع الحقوق محفوظة · خدمة تنظيف شامل في الرياض
      </p>
    </footer>
  );
}

function FloatingActions() {
  return (
    <>
      <a
        href={WHATSAPP_LINK}
        target="_blank"
        rel="noopener noreferrer"
        aria-label="تواصل عبر واتساب"
        className="fixed bottom-6 left-6 z-50 grid h-16 w-16 place-items-center rounded-full bg-emerald-500 text-white shadow-[0_14px_34px_-10px_rgba(0,0,0,0.45)] animate-floaty"
        style={{ animationDelay: "0.3s" }}
      >
        <span className="animate-ripple absolute inset-0 text-emerald-300" />
        <MessageCircle className="relative size-7" />
      </a>
      <a
        href={`tel:${PHONE_NUMBER}`}
        aria-label="اتصل بنا"
        className="fixed bottom-6 left-6 z-50 mb-20 grid h-16 w-16 place-items-center rounded-full bg-brand text-white shadow-[0_14px_34px_-10px_rgba(0,0,0,0.45)] animate-floaty"
      >
        <span className="animate-ripple absolute inset-0 text-brand-cyan" />
        <Phone className="relative size-7" />
      </a>
    </>
  );
}
